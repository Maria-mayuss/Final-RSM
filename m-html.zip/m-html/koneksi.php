<!--Koneksi ke database-->
<?php
$host = "localhost";
$username = "root";
$password ="";
$db ="contact"; //nama database
$conn = new mysqli($host, $username, $password, $db);
?>